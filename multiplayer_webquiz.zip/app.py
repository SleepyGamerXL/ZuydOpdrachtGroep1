
from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit, join_room, leave_room
import json
import random
import os

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*")

SCORE_BORD_FILE = "scorebord.json"
VRAGEN_FILE = "vragen.json"
rooms = {}  # Bevat per room de spelers, scores en huidige vraag

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('join')
def on_join(data):
    username = data['username']
    room = data['room']
    join_room(room)

    if room not in rooms:
        with open(VRAGEN_FILE) as f:
            vragen = json.load(f)
        random.shuffle(vragen)
        rooms[room] = {
            'spelers': {},
            'vragen': vragen,
            'vraag_index': 0
        }

    rooms[room]['spelers'][request.sid] = {
        'naam': username,
        'score': 0
    }
    emit('joined', {'username': username}, room=room)
    send_next_question(room)

def send_next_question(room):
    game = rooms[room]
    if game['vraag_index'] >= len(game['vragen']):
        eindscore = [
            {'naam': speler['naam'], 'score': speler['score']}
            for speler in game['spelers'].values()
        ]
        emit('quiz_einde', {'scores': eindscore}, room=room)
        return

    vraag = game['vragen'][game['vraag_index']]
    antwoorden = []
    for i in range(1, 5):
        key = f"Antwoord_{i}"
        if key in vraag and vraag[key]:
            antwoorden.append({'nummer': i, 'tekst': vraag[key]})

    emit('vraag', {
        'vraag_id': vraag['id'],
        'vraag_tekst': vraag['vraag'],
        'antwoorden': antwoorden
    }, room=room)

@socketio.on('antwoord')
def verwerk_antwoord(data):
    room = data['room']
    antwoord = data['antwoord']
    game = rooms[room]
    vraag = game['vragen'][game['vraag_index']]

    speler = game['spelers'][request.sid]
    correct = str(antwoord) == vraag['Het_antwoord']
    if correct:
        speler['score'] += 1

    emit('antwoord_feedback', {
        'naam': speler['naam'],
        'correct': correct,
        'juiste_antwoord': vraag['Het_antwoord']
    }, room=room)

    # Check of alle spelers hebben geantwoord (voor eenvoud: 2 spelers)
    if 'aantal_geantwoord' not in game:
        game['aantal_geantwoord'] = 0
    game['aantal_geantwoord'] += 1

    if game['aantal_geantwoord'] >= len(game['spelers']):
        game['vraag_index'] += 1
        game['aantal_geantwoord'] = 0
        send_next_question(room)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
