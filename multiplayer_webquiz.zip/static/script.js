const socket = io();
let currentRoom = null;
function joinGame() {
    const username = document.getElementById("username").value;
    const room = document.getElementById("room").value;
    if (!username || !room) return alert("Vul alle velden in.");
    currentRoom = room;
    socket.emit("join", { username, room });
    document.getElementById("login").style.display = "none";
    document.getElementById("quiz").style.display = "block";
}
socket.on("vraag", data => {
    document.getElementById("vraag_tekst").textContent = data.vraag_tekst;
    const antwoordenDiv = document.getElementById("antwoorden");
    antwoordenDiv.innerHTML = "";
    data.antwoorden.forEach(optie => {
        const btn = document.createElement("button");
        btn.textContent = \`\${optie.nummer}. \${optie.tekst}\`;
        btn.onclick = () => {
            socket.emit("antwoord", { room: currentRoom, antwoord: optie.nummer });
        };
        antwoordenDiv.appendChild(btn);
    });
});
socket.on("antwoord_feedback", data => {
    alert(\`\${data.naam} gaf een \${data.correct ? 'goed' : 'fout'} antwoord!\`);
});
socket.on("quiz_einde", data => {
    document.getElementById("quiz").style.display = "none";
    const scorebord = document.getElementById("scorebord");
    scorebord.innerHTML = "";
    data.scores.forEach(s => {
        const p = document.createElement("p");
        p.textContent = \`\${s.naam}: \${s.score} punten\`;
        scorebord.appendChild(p);
    });
    document.getElementById("einde").style.display = "block";
});